async function load() {
  const res = await fetch("/api/list");
  const list = await res.json();
  document.getElementById("list").innerHTML =
    list.map(p => `<li>${p.name} — ${p.url}</li>`).join("");
}

async function addProject() {
  const name = document.getElementById("name").value;
  const url = document.getElementById("url").value;

  await fetch("/api/add", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ name, url })
  });

  load();
}

load();